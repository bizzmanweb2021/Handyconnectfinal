
<div class="row mt-2">
   <div class='col-md-12'>
       <label>Scope Of Works</label>
       <select class="form form-control scopes_of_work"  name="scope-of-work[]" multiple>  
           
       </select> 
   </div>
   <!--  <div class="col-md-3">
        <h6>Price</h6>
        <input name='price' class="form form-control" required='required'>
    </div> -->
</div>
 <section class="my-1">
   <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <div class="box-header with-border ">
                    <h3 class="box-title titlefix">Services</h3>  
                </div>
                <div class="box-body  ">
                    <div class="download_label">Services  </div>
                    <table class="table-bordered services_table table table-sm" id="lead-list-table">
                        <thead> 
                            <th>Services </th> 
                            <th>Cost Price  </th> 
                            <th>Markup %</th>
                            <th>Markup Amt</th>
                            <th>Margin %</th>
                            <th>Discount %</th>
                            <th>UOM</th>
                            <th>Net Total</th> 
                            <th>Action</th> 
                        </thead>
                        <tbody style="width:1cm;"> 
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</section> 