<style>
    #scopes{ 
        text-align:justify; 
        width:100%;
    }
    select option{
        font-size: 12px;
    }
    table  tr td{
        font-size: 10pt;
    }
    #lead-list-table tbody tr td input{
        width: 2cm;
        border-color:silver;
        height: 1cm;
        border-radius: none;
    }
    label{
        font-weight: bold;
    }
</style>
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

<nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <button class="list-group-item active" id="nav-residential-tab" data-bs-toggle="tab" data-bs-target="#residential" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Residential</button>
    <button class="list-group-item" id="nav-commercial-tab" data-bs-toggle="tab" data-bs-target="#commercial" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Commercial</button> 
  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active" id=" "  role="tabpanel" aria-labelledby="nav-home-tab">
      <div class='box  px-2 py-2'> 
         <div class="justify-content-around p-1" >
        <img src="{{ url('logo/goodmanlogo.png') }}" alt="asd" style="width:100%"> 
    </div> 
        <div class="box-header with-border">
            <h4>Quotation (Interior) Detail</h4>
            <div class="box-tools float-right">
                {{-- <a href="" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i>
                    @lang('role.add') @lang('services.service')
                </a> --}}
            </div>
        </div>  
      <div class='box-body'> 
          
       <form method="POST" action="{{ route('invoice') }}" id="form"> @csrf 
            <section>
               <div class="row mt-1">
                    <div class="col-md-6">
                        <label>Customer Name</label>
                        <input type="text" class="form-control " name='customer-name' placeholder='Customer Name'>
                    </div>
                    <div class="col-md-6">
                        <label>Date</label>
                        <input type='date' name='date' class="form-control"/>
                    </div>
               </div>
            </section>
            <section>
               <div class="row mt-1">
                    <div class="col-md-6">
                       <label>Company</label>
                       <select class="form-control" name="company-name">
                           <option value="Q-GI">Goodman Interior Pte Ltd</option>
                           <option value="Q-GIS">Goodman Interior(S) Pte Ltd</option>
                           <option value="Q-GC">Goodman Creatives Pte Ltd</option>
                           <option value="Q-GE">Goodman Enterprise Pte Ltd</option>
                       </select>
                    </div> 
                </div>
                <section class='mt-2'>
                     <h4>Add Address Detail</h4>
                    <div class='row mt-1'>
                        <div class='col-md-6'>
                            <label>Address</label>
                            <input class="form-control" name='address' placeholder='Address'/>
                        </div>
                        <div class='col-md-6'>
                            <label>Country</label>
                            <input class="form-control" name='country' placeholder='Address'/>
                        </div>
                    </div>
                    <div class='row mt-1'>
                        <div class='col-md-6'>
                            <label>State</label>
                            <input class="form-control" name='state' placeholder='Address'/>
                        </div>
                        <div class='col-md-6'>
                            <label>Zip Code</label>
                            <input class="form-control" name='zip-code' placeholder='Address'/>
                        </div>
                    </div>
                    <div class='row mt-1'>
                        <div class='col-md-6'>
                            <label>E-mail</label>
                            <input class="form-control" name='e-mail' placeholder='Address'/>
                        </div>
                        <div class='col-md-6'>
                            <label>Mobile</label>
                            <input class="form-control" name='mobile' placeholder='Address'/>
                        </div>
                    </div>
                </section>
               
                <h4 class="mt-2"> Add Work Description</h4>  
                <div class="row mt-1"> 
                    <div class="col-md-6"> 
                         <div class="row" id="residential-menu">
                            <div class="col-md-12">
                               <label>Residential</label> 
                               <select class="form form-control" name='residential' >
                                  @foreach($residential as $res)
                                  <option value="{{ $res->id }}">{{ $res->type_name}}</option>
                                  @endforeach
                               </select>   

                            </div>  
                            </div>
                            <div class="row" id="commercial-menu">
                            <div class="col-md-12">
                               <label>Commercial</label>
                               <select class="form form-control" name="commercial"   >
                                   @foreach($commercial as $com)
                                   <option value="{{$com->id}}">{{$com->type_name}}</option>
                                   @endforeach
                               </select> 
                            </div>  
                           </div> 
                    </div>
                </div>
            </section>
    <div class="row mt-2">
    <div class='col-md-6'> 
    <label>List of Work Item</label> 
       <select class="form form-control select list-of-works"  id='' name="list-of-work"> 
           @foreach($work as $rows)
           <option class="text-wrap" id="{{$rows->id}}" value="{{ $rows->id }}">
               <p>{{ $rows->work_name }}</p>
           </option>
           @endforeach
       </select> 
    </div>
</div> 

<div class="row mt-2">
   <div class='col-md-12'>
       <label>Scope Of Works</label>
       <select class="form form-control scopes_of_work"  name="scope-of-work[]" multiple>  
           
       </select> 
   </div>
   <!--  <div class="col-md-3">
        <h6>Price</h6>
        <input name='price' class="form form-control" required='required'>
    </div> -->
</div>
       <section class="my-1">
          <div class="row">
                        <div class="col-md-12">
                            <div class="box box-primary">
                                <div class="box-header with-border ">
                                    <h4 class="box-title titlefix">Scope Of Works Detail</h4>  
                                </div>
                                <div class="box-body  ">
                                    <div class="download_label">Scope Of Works</div>
                                    <table class="table-bordered services_table table table-sm" id="lead-list-table">
                                        <thead> 
                                            <th>Scope Of Works </th> 
                                            <th>Cost Price  </th> 
                                            <th>Markup %</th>
                                            <th>Markup Amt</th>
                                            <th>Margin %</th>
                                            <th>Discount %</th>
                                            <th>Quantity</th>
                                            <th>Net Total</th> 
                                            <th>Action</th> 
                                        </thead>
                                        <tbody style="width:1cm;"> 
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
       </section> 
       
       <section class="mt-1">
           <div class='text-right'>
               <span>Total Price: </span>$<input name="net-price" class='ml-2 font-weight-bold total-price border-0' disabled /> <br> 
               <span>Tax: </span>$<input name='net-tax' class='ml-2 font-weight-bold total-tax border-0 ' id="total-tax" > <br>
               <span>Final Price: </span>$<input name='net-final-price' class='ml-2 font-weight-bold  border-0 final-price' id='final-price-bottom' disabled> 
           </div>
       </section>
<div class="row my-1" id="invoice-btn">
    <div class="col-md-12 text-right"> 
        <button type="submit" class="btn  btn-primary ">Save</button> 
        <a href="#" class="btn btn-danger" id='clear_all_page'>Cancel</a>
    </div>
</div>     
</form> 
</div> 
</div>
</div>
 
<script src="{{ asset('asset/admin/js/jquery.min.js') }}"></script>
<script>
$(document).ready(function(){
    
    $(document).on('click','.cancel-btn',function(){
        alert();
    });

    $.ajaxSetup({ 
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });  
    
    $(document).on('click','#clear_all_page', function(){
        location.reload();
    });

    if($('.scopes_of_work').empty()){
        console.log("not data");
    }

    $(document).on('change','.list-of-works', function(e){ 
        var id =$('.select option:selected').attr("id"); 
        if(id){
            $.ajax({
                url:'{{url("get/scope")}}'+'/'+id,
                type:'get',
                dataType:'json',
                data:{id:id},
                
                success :function(data){
                   if(data){
                    $('.scopes_of_work').empty();
                    $('.scopes_of_work').append('<optgroup label="Choose scope of work here"></optgroup>');
                    $.each(data, function(key ,scope){  
                        $('.scopes_of_work').append(
                            '<option   value="'+scope.id+'" class="select_scopes">'+ scope.work_description +'  '+ scope.work_cost +'</option>'
                        );
                    });
                   } else {
                       $('.scopes_of_work').empty();
                   }
                    
                } 
                
            })
            
            
        } else {
            $('.scopes_of_work').empty();
        }
        $('#lead-list-table').each(function(){
            $("tbody tr td").remove();
        });
    });  
    $('#commercial-menu').hide();
    $('#residential-menu').show(); 
    $('#nav-residential-tab').on('click', function(){
        $('#commercial-menu').hide();
        $('#residential-menu').show();
        $('#form').attr('action',"{{ route('invoice') }}"); 
    }); 

    $(document).on('click','#nav-commercial-tab', function(){
        $('#commercial-menu').show();
        $('#residential-menu').hide();
        $('#form').attr('action',"{{ route('invoice-commercial') }}");
    });
   
    $.ajax({
       url: "{{ url('selecte/work/lis') }}",
       type: "get",
       success: function(data){
          $.each(data, function(key, value){
              $('#selected-work').append('<td>'+value.id+'</td><td>'+value.type_of_work+'</td><td>'+value.scope_of_work+'</td>');
              
          });
          
       }
    });
   
  

    $(document).on('click','.select_scopes', function(e){
        e.preventDefault();
        var works = ($(this).text());
        var id = ($(this).attr('value'));

        $('#lead-list-table').append(
        "<tr class='added-works'><td><input type='hidden' name='scopes_stack[]' value='"+works+"'>"+works+"</td>\<td><input class='price-input form-control rounded-0' name='price[]'></td>\<input name='discount[]' class='discount form-control rounded-0'/><td><input class='markup-percent form-control rounded-0' name='markup-percent[]'></td>\<td><input class='markup-amt form-control rounded-0' name='markup-amount[]'></td>\<td><input class='margin-percent form-control rounded-0' name='margin-percent[]'></td>\<td><input class='discount-percent form-control rounded-0' name='discount-percent[]'></td>\<td><input class='quantity-input form-control rounded-0' name='quantity-input[]'></td>\<td><input class='total-input form-control rounded-0' name='net-total[]' disabled></td><td><span id='save-btn' class='alert primary' ><i class='fa fa-save'></i></span><span id='cancel-btn' class='alert danger'><i class='fa fa-trash'></></span></td>\ <tr>"
        );  
    
    });

    $(document).on('click','#save-btn', function(e){
        e.preventDefault();
        alert();
    });
 
    $(document).on('keyup','.added-works', function(e){
        var price = $(this).find('.price-input').val();
        var qty = $(this).find('.quantity-input').val();
        var tax = $(this).find('.total-input').val();
        var markup_percent = $(this).find('.markup-percent').val() ; 
        var markup_amount = $(this).find('.markup-amt').val();
        var margin_percent = $(this).find('.margin-percent').val();
        var discount_percent = $(this).find('.discount-percent').val();
        var price_qty = parseFloat(price * qty);

        markup_percent = price*markup_percent/100; 
         margin_percent = price*margin_percent/100; 
         discount_percent = price*discount_percent/100; 
         

        $(this).find('.total-input').val(parseFloat(price_qty));
        total = 0;  
        $(".total-input").each(function() {      
             total += +this.value;
              $('.total-price').val(parseFloat(total));
        }); 

       
        
    }); 

    $('table tbody').on('click', '#cancel-btn', function(){
       
        $(this).closest('tr ').remove();
    });
    
    $(document).on('keyup','.total-tax', function(){
        var price = $('.total-price').val();
        var tax = $('#total-tax').val();
        var str =  parseFloat(price*tax/100);
        var final_result = parseFloat(price-str);
       $('#final-price-bottom').val(parseFloat(final_result));

         
    });
});
</script>
