@extends('admin.layouts.main')
@section('content')

    <body class="vertical-layout vertical-menu-modern 2-columns  navbar-sticky footer-static  " data-open="click"
        data-menu="vertical-menu-modern" data-col="2-columns">

        <div class="app-content content">
            <div class="content-overlay"></div>
            <div class="content-wrapper">
                <div class="content-header row">
                    <div class="content-header-left col-12 mb-2 mt-1">
                        <div class="row breadcrumbs-top">
                            <div class="col-12">
                                <h5 class="content-header-title float-left pr-1 mb-0 text-capitalize">
                                    @lang('Assign Job')</h5>
                                <div class="breadcrumb-wrapper col-12">
                                    <ol class="breadcrumb p-0 mb-0">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard.index') }}"><i
                                                    class="bx bx-home-alt"></i></a>
                                        </li>
                                        <li class="breadcrumb-item active text-capitalize">@lang('Assign Job')
                                        </li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <div class="content-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="box box-primary">
                                <div class="box-header with-border">
                                    <h3 class="box-title titlefix">@lang('Assign Job')</h3>
                                    <div class="box-tools float-right">
                                            <a href="#!" class="btn btn-primary btn-sm"
                                                onclick="open_modal('add_subcontractor','add_subcontractor_form')"><i
                                                    class="fa fa-plus"></i>
                                                @lang('Asign Job')
                                            </a>
                                    </div>
                                </div>
                                <div class="box-body">
                                    <div class="download_label">@lang('Assign Job') @lang('role.list')</div>
                                    <table class="assign-job-list" id="assign_job_list" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>@lang('Job Unique Id')</th>
                                                <th>@lang('SC Name')</th>
                                                <th>@lang('Customer name')</th>
                                                <th>@lang('Order')</th>
                                                <th>@lang('Status')</th>
                                                {{-- <th>@lang('role.action')</th> --}}
                                            </tr>
                                        </thead>
                                        <tbody>

                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>

    {{-- modal --}}
    <div class="modal fade text-left" id="add_subcontractor" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="myModalLabel1">@lang('role.Assign') @lang('subcontractor')</h3>
                    <button type="button" class="close rounded-pill" data-dismiss="modal" aria-label="Close">
                        <i class="bx bx-x"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="add_subcontractor_form">
                        @csrf
                        <label> @lang('Subcontractor Name'): </label>
                        <div class="form-group">
                           <select name="subcontractor_name" id="sub_contractor_id" class="form-control subcontractor_list">
                            <option>
                                -----CLICK TO CHOOSE SUB CONTRACTOR-----
                            </option>
                            </select>
                        </div>
                            <label> @lang('Customer Name'): </label>
                        <div class="form-group">
                           <select name="customer_name" id="customer_id" class="form-control customer_list">
                            <option>
                                -----CLICK TO CHOOSE CUSTOMER-----
                            </option>
                            </select>
                        </div>
                            <label> @lang('Order'): </label>
                        <div class="form-group">
                           <select name="customer_order" id="customer_order_id" class="form-control customer_order">
                            <option>
                                Please Select Customer First
                            </option>
                            </select>
                        </div>
                     <!--    <label> @lang('email'): </label>
                        <div class="form-group">
                            <input type="text" placeholder="Enter Email"
                                class="form-control" name="email">
                        </div>
                        <label> @lang('mobile'): </label>
                        <div class="form-group">
                            <input type="text" placeholder="Enter mobile"
                                class="form-control" name="mobile">
                        </div>
                        <label> @lang('image'): </label>
                        <div class="form-group">
                            <input type="file" class="image_dropify" data-allowed-file-extensions="png jpg jpeg" placeholder="Enter Sub Contractors Image" name="sub_contractors_image">
                        </div>
                        <label> @lang('past_jobs'): </label>
                        <div class="form-group">
                            <input type="text" placeholder="Enter Past Jobs"
                                class="form-control" name="past_jobs">
                        </div>
                        <label> @lang('past_job_cost'): </label>
                        <div class="form-group">
                            <input type="text" placeholder="Enter Past Job Cost"
                                class="form-control" name="past_job_cost">
                        </div> -->

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light-secondary" data-dismiss="modal">
                        <i class="bx bx-x d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Close</span>
                    </button>
                    <button type="button" class="btn btn-primary ml-1" id="add_subcontractor_form_btn">
                        <i class="bx bx-check d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Save</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    {{-- end modal --}}

    {{-- edit subcontractor --}}
    <div class="modal fade text-left" id="edit_subcontractor_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="myModalLabel1">@lang('edit') @lang('subcontractor')</h3>
                    <button type="button" class="close rounded-pill" data-dismiss="modal" aria-label="Close">
                        <i class="bx bx-x"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="edit_subcontractor_form">
                        @csrf
                        <label> @lang('name'): </label>
                        <div class="form-group">
                            <input type="text" id="edit_subcontractor_name" placeholder="Enter Name"
                                class="form-control" name="name">
                        </div>
                        <label> @lang('email'): </label>
                        <div class="form-group">
                            <input type="text" id="edit_subcontractor_email" placeholder="Enter Email"
                                class="form-control" name="email">
                        </div>
                        <label> @lang('mobile'): </label>
                        <div class="form-group">
                            <input type="text" id="edit_subcontractor_mobile" placeholder="Enter mobile"
                                class="form-control" name="mobile">
                        </div>
                        <label> @lang('image'): </label>
                        <div class="form-group">
                            <div class="text-center">
                                <img src="" alt="" id="edit_subcontractors_image" width="100">
                            </div>
                            <input type="file" class="form-control image_dropify" name="sub_contractors_image"
                                data-allowed-file-extensions="png jpg jpeg">
                            <input type="hidden" name="id" id="edit_subcontractor_id">
                        </div>
                        <label> @lang('past_jobs'): </label>
                        <div class="form-group">
                            <input type="text" id="edit_subcontractor_past_jobs" placeholder="Enter Past Jobs"
                                class="form-control" name="past_jobs">
                        </div>
                        <label> @lang('past_job_cost'): </label>
                        <div class="form-group">
                            <input type="text" id="edit_subcontractor_past_job_cost" placeholder="Enter Past Job Cost"
                                class="form-control" name="past_job_cost">
                        </div>
                      
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light-secondary" data-dismiss="modal">
                        <i class="bx bx-x d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Close</span>
                    </button>
                    <button type="button" class="btn btn-primary ml-1" id="edit_subcontractor_form_btn">
                        <i class="bx bx-check d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Update</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    {{-- edit subcontractor --}}



@section('javascript')
    <script>
         $(document).ready(function() {
            get_all_subcontractor();
            
        });

        $(document).on("change","#customer_id", function(){
            var customer_unique_id = $('#customer_id').val();
            $.ajax({
                url: "{{ route('subcontractor.get_customer_order') }}",
                type: 'post',
                data: {
                    "_token": "{{ csrf_token() }}",
                    "customer_unique_id" : customer_unique_id
                },
                dataType: 'json',
                beforeSend: function() {
                    $('#main_loader').show();
                },
                success: function(data) {
                    // console.log(data)
                    $('#main_loader').hide();
                    var len = data.length;
                    $('.customer_order').empty();
                    if(len == 0) {
                        $('.customer_order').append('<option value="">No Order Found</option>')
                    }
                    for (var i = 0; i < len; i++) {
                        $('.customer_order').append('<option value="' + data[i]['order_id'] + '">' + data[i]['service']['service_name'] + ' (#'+ data[i]['service_unique_id'] +')'+
                            '</option>')
                    }

                },
                error: function(error) {
                    console.log(error)
                    $('#main_loader').hide();
                }
            })
        });
        
        function get_all_subcontractor() {
            $.ajax({
                url: "{{ route('subcontractor.get_all_subcontractor') }}",
                type: 'get',
                dataType: 'json',
                beforeSend: function() {
                    $('#main_loader').show();
                },
                success: function(data) {
                    // console.log(data)
                    $('#main_loader').hide();
                    var len = data.length;
                    $('.subcontractor_list').empty();
                    for (var i = 0; i < len; i++) {
                        $('.subcontractor_list').append('<option value="' + data[i]['id'] + '">' + data[i]['name'] +
                            '</option>')
                    }

                },
                error: function(error) {
                    console.log(error)
                    $('#main_loader').hide();
                }
            })
        }

    $(document).ready(function() {
            get_all_customer();
        });

         function get_all_customer() {
            $.ajax({
                url: "{{ route('admin.customer.get_all_customer') }}",
                type: 'get',
                dataType: 'json',
                beforeSend: function() {
                    $('#main_loader').show();
                },
                success: function(data) {
                    // console.log(data)
                    $('#main_loader').hide();
                    var len = data.length;
                    $('.customer_list').empty();
                    $('.customer_list').append('<option value="">Select Customer</option>')
                    for (var i = 0; i < len; i++) {
                        $('.customer_list').append('<option value="' + data[i]['customer_unique_id'] + '">' + data[i]['name'] +
                            '</option>')
                    }

                },
                error: function(error) {
                    console.log(error)
                    $('#main_loader').hide();
                }
            })
        }

        $('#main_delete_link').click(function(e) {
            e.preventDefault();
            delete_modal_selected_data("{{ route('subcontractor.delete_job') }}", $(this).attr('href'),
                "{{ csrf_token() }}");
            assign_job_list.ajax.reload();
        });

        function open_edit_subcontractor_model(id) {
            $('#edit_subcontractor_modal').modal('show');
            $.ajax({
                url: "{{ route('subcontractor.edit_job') }}",
                type: 'get',
                data: {
                    id: id
                },
                dataType: 'json',
                beforeSend: function() {
                    $('#main_loader').show();
                },
                success: function(data) {
                    // console.log(data)
                    var url = "{{ asset('') }}";
                    $('#edit_subcontractor_id').val(data.id);
                    $('#edit_subcontractor_name').val(data.name);
                    $('#edit_subcontractor_email').val(data.email);
                    $('#edit_subcontractor_mobile').val(data.mobile);
                    $('#edit_subcontractor_past_jobs').val(data.past_jobs);
                    $('#edit_subcontractor_past_job_cost').val(data.past_job_cost);
                    
                    $('#main_loader').hide();

                },
                error: function(error) {
                    // console.log(error);
                    $('#main_loader').hide();
                }
            })
        }

        $('#edit_subcontractor_form_btn').click(function(e) {
            e.preventDefault();
            var form = $('#edit_subcontractor_form')[0];
            var data = new FormData(form);
            $.ajax({
                url: "{{ route('subcontractor.update_job') }}",
                type: 'post',
                data: data,
                dataType: 'json',
                cache: false,
                processData: false,
                contentType: false,
                beforeSend: function(data) {
                    show_when_ajax_call('#edit_subcontractor_form_btn', 'edit_subcontractor_form');
                },
                success: function(data) {
                    console.log(data);
                    if (data.status == 'success') {
                        close_modal('edit_subcontractor_modal');
                        remove_after_ajax_call('#edit_subcontractor_form_btn', 'edit_subcontractor_form','Update')
                        successMsg(data.message);
                        assign_job_list.ajax.reload();
                        close_modal('edit_subcontractor_modal')
                    }
                },
                error: function(error) {
                    show_errors_when_ajax_call('#edit_subcontractor_form_btn', 'edit_subcontractor_form', error,'Update');
                }
            })
        })


        $('#add_subcontractor_form_btn').click(function(e) {
            e.preventDefault();
            var form = $('#add_subcontractor_form')[0];
            var data = new FormData(form);
            $.ajax({
                url: "{{ route('subcontractor.store_job') }}",
                type: 'post',
                data: data,
                dataType: 'json',
                cache: false,
                processData: false,
                contentType: false,
                beforeSend: function(data) {
                    show_when_ajax_call('#add_subcontractor_form_btn', 'add_subcontractor_form');
                },
                success: function(data) {
                    // console.log(data);
                    if (data.status == 'success') {
                        close_modal('add_subcontractor');
                        remove_after_ajax_call('#add_subcontractor_form_btn', 'add_subcontractor_form')
                        successMsg(data.message);
                        assign_job_list.ajax.reload();
                        close_modal('add_subcontractor')
                    }
                },
                error: function(error) {
                    show_errors_when_ajax_call('#add_subcontractor_form_btn', 'add_subcontractor_form', error);
                }
            })
        })

        var dataTable

        $(document).ready(function() {
            assign_joblist = $('.assign-job-list').DataTable({
                
            
                "aaSorting": [],


                rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                
                ajax: {
                    url: "{{ route('subcontractor.create_job') }}",
                    type: 'get',

                },
                //responsive: 'false',
                dom: "Bfrtip",
                buttons: [

                    {
                        extend: 'copyHtml5',
                        text: '<i class="fas fa-file"></i>',
                        titleAttr: 'Copy',
                        title: $('.download_label').html(),
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'excelHtml5',
                        text: '<i class="fa fa-file-excel"></i>',
                        titleAttr: 'Excel',

                        title: $('.download_label').html(),
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'csvHtml5',
                        text: '<i class="fa fa-file-text"></i>',
                        titleAttr: 'CSV',
                        title: $('.download_label').html(),
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'pdfHtml5',
                        text: '<i class="fa fa-file-pdf"></i>',
                        titleAttr: 'PDF',
                        title: $('.download_label').html(),
                        exportOptions: {
                            columns: ':visible'

                        }
                    },

                    {
                        extend: 'print',
                        text: '<i class="fa fa-print"></i>',
                        titleAttr: 'Print',
                        title: $('.download_label').html(),
                        customize: function(win) {
                            $(win.document.body)
                                .css('font-size', '10pt');

                            $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                        },
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'colvis',
                        text: '<i class="fa fa-columns"></i>',
                        titleAttr: 'Columns',
                        title: $('.download_label').html(),
                        postfixButtons: ['colvisRestore']
                    },
                ],
              
                columns:  [
                    {
                        data: 'job_unique_id',
                        name: 'job_unique_id'
                    },
                    {
                        data: 'scname',
                        name: 'scname'
                    },
                    {
                        data: 'customer_name',
                        name: 'customer_name'
                    },
                    {
                        data: 'order_id',
                        name: 'order_id'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: true, 
                        searchable: true
                    }

                ]
            })
        });
    </script>
@endsection

@endsection
